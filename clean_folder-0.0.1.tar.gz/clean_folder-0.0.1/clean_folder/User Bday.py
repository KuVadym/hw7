import datetime
import collections
users = collections.namedtuple('colleague', ['name', 'last_name', 'birth_date', 'position'])

users_info = []
users_info.append (users('Ihor','Matvienko' ,datetime.datetime(year=1960, month=2, day=6,) ,'CEO' ))


def get_birthdays_per_week(users):


    print ("Employee who have B-day")
