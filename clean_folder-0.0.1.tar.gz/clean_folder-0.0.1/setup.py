from setuptools import setup

setup(name='clean_folder',
      version='0.0.1',
      description='script for folder sort',
      url='http://github.com/dummy_user/useful',
      author='KuVadym',
      author_email='KuVadym@example.com',
      license='MIT',
      packages=['clean_folder'],
      entry_points={'console_scripts': ['clean_folder = clean_folder.clean']})